# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.shortcuts import render
from . serializers import *
from rest_framework.views import APIView

from rest_framework.permissions import IsAuthenticated

from rest_framework_simplejwt.authentication import JWTAuthentication

from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework.response import Response

# Storeoffice class
class ProductAPIView(APIView):
    def get_object(self,pk):
        try:
            return Product.objects.get(pk=pk)
        except Product.DoesNotExist:
            raise
    def get(self,request,pk=None,format=None):
        if pk:
            data=self.get_object(pk)
            serializer=ProductSerializer(data)
            return Response(serializer.data)
        else:
            data=Product.objects.all()
            serializer=ProductSerializer(data,many=True)
            return Response(serializer.data)

    def post(self,request,format=None):
        data=request.data
        serializer=ProductSerializer(data=data)

        serializer.is_valid(raise_exception=True)
        serializer.save()
        response=Response()
        response.data={
            'message':'Product Add Successfully',
            'data':serializer.data
        }
        return response

    def put(self, request,pk=None, format=None):
        Product_to_update=Product.objects.get(pk=pk)
        serializer = ProductSerializer(instance=Product_to_update,data=request.data,partial=True)

        serializer.is_valid()
        serializer.save()
        response = Response()
        response.data = {
            'message': 'Product Updated Successfully',
            'data': serializer.data
        }
        return response
    def delete(self, request,pk,format=None):
        Product_to_delete=Product.objects.get(pk=pk)
        Product_to_delete.delete()
        return Response({
            'message':'Product deleted successfully'
        })

# PRODUCT DEATILS
class UserAPIView(APIView):
    
    def get_object(self,pk):
        try:
            return User.objects.get(pk=pk)
        except User.DoesNotExist:
            raise
    def get(self,request,pk=None,format=None):
        if pk:
            data=self.get_object(pk)
            serializer=UserSerializer(data)
            return Response(serializer.data)
        else:
            data=User.objects.all()
            serializer=UserSerializer(data,many=True)
            return Response(serializer.data)

    def post(self,request,format=None):
        data=request.data
        serializer=UserSerializer(data=data)

        serializer.is_valid(raise_exception=True)
        serializer.save()
        response=Response()
        response.data={
            'message':'User details Created Successfully',
            'data':serializer.data
        }
        return response

    def put(self, request,pk=None, format=None):
        User_to_update=User.objects.get(pk=pk)
        serializer = UserSerializer(instance=User_to_update,data=request.data,partial=True)

        serializer.is_valid()
        serializer.save()
        response = Response()
        response.data = {
            'message': 'User details Updated Successfully',
            'data': serializer.data
        }
        return response
    def delete(self, request,pk,format=None):
        User_to_delete=User.objects.get(pk=pk)
        User_to_delete.delete()
        return Response({
            'message':'User details deleted successfully'
        })


class CategoryAPIView(APIView):
    
    def get_object(self,pk):
        try:
            return User.objects.get(pk=pk)
        except User.DoesNotExist:
            raise
    def get(self,request,pk=None,format=None):
        if pk:
            data=self.get_object(pk)
            serializer=CategorySerializer(data)
            return Response(serializer.data)
        else:
            data=User.objects.all()
            serializer=CategorySerializer(data,many=True)
            return Response(serializer.data)

    def post(self,request,format=None):
        data=request.data
        serializer=CategorySerializer(data=data)

        serializer.is_valid(raise_exception=True)
        serializer.save()
        response=Response()
        response.data={
            'message':'Category Added Successfully',
            'data':serializer.data
        }
        return response





class Sub_CategoryAPIView(APIView):
    def get_object(self,pk):
        try:
            return User.objects.get(pk=pk)
        except User.DoesNotExist:
            raise
    def get(self,request,pk=None,format=None):
        if pk:
            data=self.get_object(pk)
            serializer=Sub_CategorySerializer(data)
            return Response(serializer.data)
        else:
            data=User.objects.all()
            serializer=Sub_CategorySerializer(data,many=True)
            return Response(serializer.data)

    def post(self,request,format=None):
        data=request.data
        serializer=Sub_CategorySerializer(data=data)

        serializer.is_valid(raise_exception=True)
        serializer.save()
        response=Response()
        response.data={
            'message':'Sub_Category Added Successfully',
            'data':serializer.data
        }
        return response



class DashboardDetailsAPIView(APIView):
    def get_object(self,pk):
        try:
            return User.objects.get(pk=pk)
        except User.DoesNotExist:
            raise
    def get(self,request,pk=None,format=None):
        if pk:
            data=self.get_object(pk)
            serializer=DashboardDetailsSerializer(data)
            return Response(serializer.data)
        else:
            data=User.objects.all()
            serializer=DashboardDetailsSerializer(data,many=True)
            return Response(serializer.data)
