# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models

# Create your models here.
from django.db import models

# Create your models here.

class Product(models.Model):
    product_id = models.AutoField(primary_key=True)
    product_name=models.CharField(max_length=50)
    product_size = models.IntegerField(blank=True, null=True)
    product_quantity = models.IntegerField()
    product_cost= models.DecimalField(max_digits=19, decimal_places=2, null=False, blank=False)
    product_total_cost = models.IntegerField()
    product_description = models.TextField()
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)

    def __str__(self):
        return self.product_name

class Sub_Category(models.Model):
    TYPES = (('CON','CONSUMABLE'), ('NON_CON','NON_CONSUMABLE'))
    subcategory_name =models.CharField(max_length=50)
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True)


    class Meta:
        verbose_name_plural='Sub-category'

    def __str__(self):
        return self.subcategory_name

class Category(models.Model):

    category_name =models.CharField(max_length=50)
    category = models.ForeignKey(Sub_Category, on_delete=models.CASCADE, related_name="products_sub_category", null=True,blank=True)
    TYPES = (('CON', 'CONSUMABLE'), ('NON-CON', 'NON-CONSUMABLE'))
    created_date = models.DateTimeField(auto_now_add=True)
    updated_date = models.DateTimeField(auto_now=True, null=True, blank=True)
    def __str__(self):
        return self.category_name

    class Meta:
        verbose_name_plural='Category'




class User(models.Model):
    full_name=models.CharField(max_length=50)
    email = models.EmailField(max_length=50)
    mobile_no=models.IntegerField()
    designation=models.CharField(max_length=50)
    username=models.CharField(max_length=200)
    password=models.CharField(max_length=50)



    def __str__(self):
        return self.username


class DashboardDetails(models.Model):
    total_stock= models.IntegerField()
    total_category = models.IntegerField()
    total_subcategory = models.IntegerField()
    total_user = models.IntegerField()



