

from django.urls import path
from.views import *



urlpatterns = [
    path('dashboard/', DashboardDetailsAPIView.as_view(),name='Dashboard'),

    path('product/',ProductAPIView.as_view()),
    path('product/<int:pk>/', ProductAPIView.as_view()),

    path('user/',UserAPIView.as_view()),
    path('user/<int:pk>/', UserAPIView.as_view()),

    path('category/', CategoryAPIView.as_view(), name='category-list'),
    path('subcategory/', Sub_CategoryAPIView.as_view(), name='sub_category-list'),

]
